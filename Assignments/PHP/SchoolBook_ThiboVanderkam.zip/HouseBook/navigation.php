<nav>
    <ul>
        <li>
            <a href="slytherin.php">
                slytherin
            </a>
        </li>
        <li>
            <a href="gryffindor.php">
                gryffindor
            </a>
        </li>
        <li>
            <a href="ravenclaw.php">
                ravenclaw
            </a>
        </li>
        <li>
            <a href="hufflepuff.php">
                hufflepuff
            </a>
        </li>
    </ul>
</nav>