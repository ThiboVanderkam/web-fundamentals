<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
        <!-- Navigation -->
        <?php
            include "navigation.php";
        ?>

        <img src="images/slytherin.jpeg" />

        <h1>
            Slytherin
        </h1>

        <p>
            What does Slytherin mean? Slytherin is one of the four houses of Hogwarts School of Witchcraft and Wizardry in J.K. Rowling's Harry Potter series. Each house has a set of traits and characteristics associated with it, and those in Slytherin are known for being ambitious, cunning, and resourceful.
        </p>


    </body>
</html>